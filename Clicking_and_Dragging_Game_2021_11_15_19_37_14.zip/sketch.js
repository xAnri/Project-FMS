function setup() {
  
  createCanvas(800, 600);
}

function draw() {
  background(300);
  scale(1);
  stroke(5);
  fill(68, 114, 196);
  //blue
  rect(10, 10, 780, 580, 40); //left rectangle
  fill(255, 255, 255);
  //white
  rect(190, 90, 580, 480, 35); //bottom right rectangle
  fill(237, 125, 49);
  //orange stuff
  rect(190, 30, 580, 45, 25);
  rect(30, 30, 140, 540, 30);
  rect(725, 565, 70, 30, 45);
  fill(255, 255, 255);
  textSize(36);
  text("Clicking and Dragging Game", 260, 65);
  textSize(18);
  text("Instructions:", 35, 80);
}