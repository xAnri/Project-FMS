let score = 0;
const radius = 15;
let x, y;
function setup() {
  createCanvas(800, 600);
  x = random(220, 750);
  y = random(110, 550);
}

function draw() {
  background(300);
  scale(1);
  stroke(5);
  fill(68, 114, 196);
  //blue
  rect(10, 10, 780, 580, 40); //left rectangle
  fill(255, 255, 255);
  //white
  rect(190, 90, 580, 480, 35); //bottom right rectangle
  fill(237, 125, 49);
  //orange stuff
  rect(190, 30, 580, 45, 25);
  rect(30, 30, 140, 540, 30);
  rect(655, 565, 140, 30, 45);
  fill(255, 255, 255);
  textSize(36);
  text("Clicking Game", 360, 65);
  textSize(18);
  text("Instructions:", 35, 80);
  textSize(16);
  noStroke();
  text("Press '0' for Home", 660, 585)
  //instructions
  text("The blue ball", 35, 110);
  text("will move to a", 35, 140);
  text("random location", 35, 170);
  text("every 3 seconds.", 35, 200);
  text("It will also", 35, 230);
  text("move if left", 35, 260);
  text("click. Each match", 35, 290);
  text("will add 1 point", 35, 320);
  text("to your score.", 35, 350);
  stroke(1);
  textSize(22);
  fill(68, 144, 196);
  text("SCORE: " + score, 35, 530);
  ellipse(x, y, radius * 2, radius * 2);
}

function keyPressed() {
  if (keyCode === 48)
 window.open("https://editor.p5js.org/dsabic1/full/JAS2cvpkd4")
}


function mousePressed() {
  let d = dist(mouseX, mouseY, x, y);
  if (d < radius){
    newCircle();
    score++;
  }
}

function newCircle() {
  x = random(220, 750);
  y = random(110, 550);
}


setInterval(newCircle, 1800);
