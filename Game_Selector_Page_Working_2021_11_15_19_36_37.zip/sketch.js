function setup() {
  createCanvas(800, 600);
}

function keyPressed() {
  if (keyCode === 49)
 window.open("https://editor.p5js.org/dsabic1/full/O6J6zG9mX")

  if (keyCode === 50)
 window.open("https://editor.p5js.org/dsabic1/full/1V8UkVhZi")

  if (keyCode === 51)
 window.open("https://editor.p5js.org/dsabic1/full/bovEfRnb-")

  if (keyCode === 52)
 window.open("https://editor.p5js.org/dsabic1/full/5D4fBg8Xr")
}

function draw() {
  background(300);
  scale(1);
  stroke(5);
  fill(68, 114, 196);
  //blue
  rect(10, 10, 780, 580, 40); //left rectangle
  fill(255, 255, 255);
  //white
  rect(190, 90, 580, 480, 35); //bottom right rectangle
  fill(237, 125, 49);
  //orange stuff
  rect(190, 30, 580, 45, 25);
  rect(30, 30, 140, 540, 30);
  fill(237, 125, 49);
  rect(210, 110, 540, 80, 20); //bottom right orange rectangle
  rect(210, 230, 540, 80, 20);
  rect(210, 350, 540, 80, 20);
  rect(210, 470, 540, 80, 20);
  fill(255, 255, 255);
  textSize(32);
  text("Select Game", 390, 64);
  textSize(45);
  text("Clicking [1]", 220, 165);
  text("Clicking and Dragging [2]", 220, 285)
  text("Move Object [3]", 220, 405)
  text("Typing Match [4]", 220, 525)
  textSize(16);
  text("Hit [#] on the", 60, 200);
  text("keyboard to", 60, 270);
  text("select game", 60, 340);
 
}

