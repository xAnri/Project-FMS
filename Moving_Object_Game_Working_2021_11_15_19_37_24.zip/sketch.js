var food;

var timer = 50;

var score = 0;

function setup() {
  createCanvas(800, 600);
  player = new player();
  food = new food();
}

function keyPressed() {
  if (keyCode === RIGHT_ARROW) {
    player.direction(3, 0);
  } else if (keyCode === DOWN_ARROW) {
    player.direction(0, 3);
  } else if (keyCode === UP_ARROW) {
    player.direction(0, -3);
  } else if (keyCode === LEFT_ARROW) {
    player.direction(-3, 0);
  }
  if (keyCode === 48) {
    window.open("https://editor.p5js.org/dsabic1/full/JAS2cvpkd4");
  }
}

function draw() {
  background(300);
  scale(1);
  stroke(5);
  fill(68, 114, 196);
  //blue
  rect(10, 10, 780, 580, 40); //left rectangle
  fill(255, 255, 255);
  //white
  rect(190, 90, 580, 480, 35); //bottom right rectangle
  fill(237, 125, 49);
  //orange stuff
  rect(190, 30, 580, 45, 25);
  rect(30, 30, 140, 540, 30);
  rect(655, 565, 140, 30, 45);
  fill(255, 255, 255);
  textSize(36);
  text("Moving Object Game", 320, 65);
  textSize(18);
  text("Instructions:", 35, 110);
  textSize(16);
  text("Press '0' for Home", 660, 585);
  text("Puck-man is", 35, 150);
  text("controlled by the", 35, 180);
  text("arrow keys. Hit", 35, 210);
  text("the blue dot to", 35, 240);
  text("gain score. The", 35, 270);
  text("blue dot will", 35, 300);
  text("move to a random", 35, 330);
  text("location afterward.", 35, 360);

  player.update();
  player.show();
  food.show();
  player.eat();

  fill(255);
  textSize(15);
  text("Time Left :" + timer, 57, 52);

  if (frameCount % 60 == 0 && timer > 0) {
    timer--;
  }

  if (timer == 0) {
    textSize(40);
    text("You Scored : " + score, width / 2, height / 2);

    food.x = -10;
    food.y = -10;
  }
}

function food() {
  this.x = random(210, 460);
  this.y = random(110, 460);
  this.show = function () {
    fill(68, 144, 196);
    circle(this.x, this.y, 20);
  };
}

function player() {
  this.x = 220;
  this.y = 110;

  this.xmove = 1;
  this.ymove = 0;

  this.direction = function (x, y) {
    player.xmove = x;
    player.ymove = y;
  };

  this.eat = function () {
    var loc = dist(this.x, this.y, food.x, food.y);
    if (loc < 10) {
      food.x = random(210, 460);
      food.y = random(110, 460);
      score++;
    }
  };

  this.update = function () {
    this.x = this.x + this.xmove;
    this.y = this.y + this.ymove;

    this.x = constrain(this.x, 0, width);
    this.y = constrain(this.y, 0, height);
  };

  this.show = function () {
    fill("yellow");
    circle(this.x, this.y, 10, 10);
  };
}
